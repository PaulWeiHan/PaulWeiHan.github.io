

```python
import os
os.chdir('/home/renwh/gaze/renwh/caffe_with_cudnnv3/')

import sys
sys.path.insert(0,'./python')
import caffe

from pylab import *
%matplotlib inline


caffe.set_device(0)
caffe.set_mode_gpu()
solver = caffe.SGDSolver('examples/mymodel/03/lenet_solver.prototxt')

#You can choose to load your model status
#solver.restore('examples/mymodel/03/lenet_iter_1001.solverstate')
```


```python
# each output is (batch size, feature dim, spatial dim)
[(k, v.data.shape) for k, v in solver.net.blobs.items()]
```




    [('data', (1000, 1, 36, 60)),
     ('label', (1000, 6)),
     ('gaze', (1000, 3)),
     ('headpose', (1000, 3)),
     ('conv1', (1000, 20, 32, 56)),
     ('pool1', (1000, 20, 16, 28)),
     ('conv2', (1000, 40, 14, 26)),
     ('pool2', (1000, 40, 7, 13)),
     ('conv3', (1000, 60, 4, 10)),
     ('pool3', (1000, 60, 2, 5)),
     ('flatdata', (1000, 600)),
     ('cat', (1000, 603)),
     ('ip1', (1000, 300)),
     ('ip2', (1000, 3)),
     ('loss', ())]




```python
# just print the weight sizes (not biases)
[(k, v[0].data.shape) for k, v in solver.net.params.items()]
```




    [('conv1', (20, 1, 5, 5)),
     ('conv2', (40, 20, 3, 3)),
     ('conv3', (60, 40, 4, 4)),
     ('ip1', (300, 603)),
     ('ip2', (3, 300))]




```python
solver.net.forward()  # train net
solver.test_nets[0].forward()  # test net (there can be more than one)
```




    {'loss': array(0.48893219232559204, dtype=float32)}




```python
# we use a little trick to tile the first eight images
imshow(solver.test_nets[0].blobs['data'].data[:8, 0].transpose(1, 0, 2).reshape(36, 8*60), cmap='gray')
print solver.net.blobs['label'].data[:8]
```

    [[ -2.44513273e-01   5.20949736e-02  -9.68245506e-01  -5.07045567e-01
       -1.12138920e-01  -2.90884897e-02]
     [ -7.41908699e-02   2.27922529e-01  -9.70848620e-01  -1.28387764e-01
        1.65355857e-02   1.06296828e-03]
     [ -1.74087971e-01   3.04691344e-02  -9.84258592e-01  -9.52000245e-02
       -3.14195365e-01  -1.50917871e-02]
     [ -2.49744281e-02   1.77879885e-01  -9.83735263e-01  -7.38587156e-02
       -1.21144764e-02  -4.47588827e-04]
     [ -1.61419377e-01   5.79187945e-02  -9.85184848e-01  -1.06810793e-01
        1.42905980e-01   7.65229668e-03]
     [ -1.52415037e-01   2.09456533e-01  -9.65866268e-01  -5.29863574e-02
       -1.14266567e-01  -3.03129526e-03]
     [ -1.76816806e-02   6.62708879e-02  -9.97644961e-01  -6.35477304e-02
       -2.95568883e-01  -9.46362782e-03]
     [  1.79661021e-01   2.34958977e-01  -9.55257118e-01  -8.40480402e-02
        1.60711512e-01   6.77234307e-03]]



![png](output_4_1.png)



```python
solver.step(1)
```


```python
imshow(solver.net.params['conv1'][0].diff[:, 0].reshape(4, 5, 5, 5)
       .transpose(0, 2, 1, 3).reshape(4*5, 5*5), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f9c1991eb10>




![png](output_6_1.png)


Show the conv1 weights pics.


Then, I will train the model, and log some information.


```python
%%time
niter = 1000
test_interval = 25
# losses will also be stored in the log
train_loss = zeros(niter)
mean_error= zeros(int(np.ceil(niter / test_interval)))
output = zeros((niter, 8, 3))

# the main solver loop
for it in range(niter):
    solver.step(1)  # SGD by Caffe
    
    # store the train loss
    train_loss[it] = solver.net.blobs['loss'].data
    
    # store the output on the first test batch
    # (start the forward pass at conv1 to avoid loading new data)
    solver.test_nets[0].forward(start='conv1')
    output[it] = solver.test_nets[0].blobs['ip2'].data[:8]
    if it % test_interval == 0:
        # caculate the square error for each gaze vector
        solver.test_nets[0].forward()
        
        num_test = 100;
        sub_error = zeros((num_test, 3))
        square_error = zeros((num_test, 3))
        sum_square_error = zeros(num_test)
        for i in range(num_test):
            sub_error[i,:] = np.subtract(solver.test_nets[0].blobs['label'].data[i,:3]
                                         , solver.test_nets[0].blobs['ip2'].data[i])
            square_error = np.square(sub_error)
            sum_square_error = np.sum(square_error,1)
        mean_error[it // test_interval] = np.sum(sum_square_error,0)/num_test*180
        print 'Iteration', it, '. Mean error is', mean_error[it // test_interval]
```

    Iteration 0 . Mean error is 144.267699581
    Iteration 25 . Mean error is 9.47200367473
    Iteration 50 . Mean error is 7.33020512891
    Iteration 75 . Mean error is 6.24437523738
    Iteration 100 . Mean error is 8.7970933519
    Iteration 125 . Mean error is 5.84686956688
    Iteration 150 . Mean error is 6.73982151862
    Iteration 175 . Mean error is 4.51951785623
    Iteration 200 . Mean error is 4.59054209276
    Iteration 225 . Mean error is 6.83399218913
    Iteration 250 . Mean error is 4.08168702746
    Iteration 275 . Mean error is 6.41484773641
    Iteration 300 . Mean error is 3.63852182673
    Iteration 325 . Mean error is 3.17272277081
    Iteration 350 . Mean error is 4.5935417196
    Iteration 375 . Mean error is 3.73231038487
    Iteration 400 . Mean error is 5.78241957345
    Iteration 425 . Mean error is 2.78607113412
    Iteration 450 . Mean error is 3.34237517488
    Iteration 475 . Mean error is 3.33277733828
    Iteration 500 . Mean error is 3.13475038103
    Iteration 525 . Mean error is 5.71074053281
    Iteration 550 . Mean error is 2.64554230274
    Iteration 575 . Mean error is 3.32742064112
    Iteration 600 . Mean error is 2.92161084961
    Iteration 625 . Mean error is 2.85147569941
    Iteration 650 . Mean error is 5.44821437845
    Iteration 675 . Mean error is 2.3163798485
    Iteration 700 . Mean error is 3.49675013724
    Iteration 725 . Mean error is 2.59828639367
    Iteration 750 . Mean error is 2.50464323342
    Iteration 775 . Mean error is 5.45948647014
    Iteration 800 . Mean error is 2.51048464222
    Iteration 825 . Mean error is 3.76720837748
    Iteration 850 . Mean error is 2.83141099882
    Iteration 875 . Mean error is 2.54668622349
    Iteration 900 . Mean error is 4.92122632919
    Iteration 925 . Mean error is 2.49665119399
    Iteration 950 . Mean error is 4.08779246248
    Iteration 975 . Mean error is 2.50338726535
    CPU times: user 52.6 s, sys: 7.13 s, total: 59.7 s
    Wall time: 59.7 s



```python
_, ax1 = subplots()
ax2 = ax1.twinx()
ax1.plot(arange(niter), train_loss)
ax2.plot(test_interval * arange(len(mean_error)), mean_error, 'r')
ax1.set_xlabel('iteration')
ax1.set_ylabel('train loss')
ax2.set_ylabel('mean error')
```




    <matplotlib.text.Text at 0x7f9c197fe850>




![png](output_9_1.png)


**show you the train loss curve.


```python
num_test = 1000


# (start the forward pass at conv1 to avoid loading new data)
solver.test_nets[0].forward(start='conv1')
solver.test_nets[0].forward()

#figure(figsize=(10, 5))
#imshow(solver.test_nets[0].blobs['data'].data[:num_test, 0].transpose(1, 0, 2).reshape(36, num_test*60), cmap='gray')
    
# print the label and train result
#for i in range(num_test):
#    print solver.test_nets[0].blobs['label'].data[i,:3] ,'label<->ip3', solver.test_nets[0].blobs['ip3'].data[i]

print '--------------------------------------------------------------------------------------------------------------'
# caculate the square error for each gaze vector
sub_error = zeros((num_test, 3))
square_error = zeros((num_test, 3))
sum_square_error = zeros(num_test)
for i in range(num_test):
    sub_error[i,:] = np.subtract(solver.test_nets[0].blobs['label'].data[i,:3], solver.test_nets[0].blobs['ip2'].data[i])
    square_error = np.square(sub_error)
    sum_square_error = np.sum(square_error,1)
    #print sub_error[i,:],square_error[i,:],sum_square_error[i]
    #print sum_square_error[i],

print num_test,'test pic, mean error is ',np.sum(sum_square_error,0)/num_test*180,'degree'
_, ax1 = subplots()
ax1.plot(arange(num_test), sum_square_error*180,'bo', label='sampled')
ax1.set_xlabel('num_test')
ax1.set_ylabel('sum_square_error')
    
```

    --------------------------------------------------------------------------------------------------------------
    1000 test pic, mean error is  2.57264414415 degree





    <matplotlib.text.Text at 0x7f9c19747ad0>




![png](output_11_2.png)



```python
imshow(solver.net.params['conv1'][0].diff[:, 0].reshape(4, 5, 5, 5)
       .transpose(0, 2, 1, 3).reshape(4*5, 5*5), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f9c199e9fd0>




![png](output_12_1.png)



```python
figure(figsize=(10, 5))
imshow(solver.net.params['conv2'][0].diff[:, 0].reshape(4, 10, 3, 3)
       .transpose(0, 2, 1, 3).reshape(4*3, 10*3), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f9c19620090>




![png](output_13_1.png)



```python
figure(figsize=(10, 5))
imshow(solver.net.params['conv3'][0].diff[:, 0].reshape(6, 10, 4, 4)
       .transpose(0, 2, 1, 3).reshape(6*4, 10*4), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f9c195c7590>




![png](output_14_1.png)



```python
figure(figsize=(20, 10))
imshow(solver.test_nets[0].blobs['conv1'].data[:8, :].reshape(8,20,32,56)
           .transpose(0,2,1,3).reshape(8*32, 20*56), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f9c194fc290>




![png](output_15_1.png)



```python
figure(figsize=(20, 10))
imshow(solver.test_nets[0].blobs['conv2'].data[:8, :].reshape(16, 20, 14, 26)
       .transpose(0,2,1,3).reshape(16*14, 20*26), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f9c18c60150>




![png](output_16_1.png)



```python
figure(figsize=(50, 25))
imshow(solver.test_nets[0].blobs['conv3'].data[:8, :].reshape(16, 30, 4, 10)
       .transpose(0,2,1,3).reshape(16*4, 30*10), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f9c183bdf50>




![png](output_17_1.png)



```python
#solver.net.save('my_model.caffemodel') I do not know how to use this.
solver.snapshot() #SAVE MY MODEL IN THE DIR YOU DEFINE IN SOLVER FILE.
```


```python

```
