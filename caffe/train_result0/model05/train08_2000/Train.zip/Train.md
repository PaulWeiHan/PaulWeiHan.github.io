

```python
import os
os.chdir('/home/renwh/gaze/renwh/caffe_with_cudnnv3/')

import sys
sys.path.insert(0,'./python')
import caffe

from pylab import *
%matplotlib inline


caffe.set_device(0)
caffe.set_mode_gpu()
solver = caffe.SGDSolver('examples/mymodel/05/quick_solver.prototxt')

#You can choose to load your model status
#solver.restore('examples/mymodel/03/lenet_iter_1001.solverstate')
```


```python
# each output is (batch size, feature dim, spatial dim)
[(k, v.data.shape) for k, v in solver.net.blobs.items()]
#[(k, v.data.shape) for k, v in solver.test_nets[0].blobs.items()]
```




    [('data', (500, 1, 36, 60)),
     ('label', (500, 6)),
     ('gaze', (500, 3)),
     ('headpose', (500, 3)),
     ('conv1/5x5_s1', (500, 64, 32, 56)),
     ('pool1/3x3_s2', (500, 64, 16, 28)),
     ('pool1/norm1', (500, 64, 16, 28)),
     ('pool1/norm1_pool1/norm1_0_split_0', (500, 64, 16, 28)),
     ('pool1/norm1_pool1/norm1_0_split_1', (500, 64, 16, 28)),
     ('pool1/norm1_pool1/norm1_0_split_2', (500, 64, 16, 28)),
     ('pool1/norm1_pool1/norm1_0_split_3', (500, 64, 16, 28)),
     ('inception_1/1x1', (500, 64, 16, 28)),
     ('inception_1/3x3_reduce', (500, 96, 16, 28)),
     ('inception_1/3x3', (500, 128, 16, 28)),
     ('inception_1/5x5_reduce', (500, 16, 16, 28)),
     ('inception_1/5x5', (500, 32, 16, 28)),
     ('inception_1/pool', (500, 64, 16, 28)),
     ('inception_1/pool_proj', (500, 32, 16, 28)),
     ('inception_1/output', (500, 256, 16, 28)),
     ('pool2/3x3_s2', (500, 256, 8, 14)),
     ('conv2/3x3_s1', (500, 64, 6, 12)),
     ('pool3/2x2_s2', (500, 64, 3, 6)),
     ('ip1', (500, 500)),
     ('cat', (500, 503)),
     ('ip2', (500, 3)),
     ('loss', ())]




```python
# just print the weight sizes (not biases)
[(k, v[0].data.shape) for k, v in solver.net.params.items()]
```




    [('conv1/5x5_s1', (64, 1, 5, 5)),
     ('inception_1/1x1', (64, 64, 1, 1)),
     ('inception_1/3x3_reduce', (96, 64, 1, 1)),
     ('inception_1/3x3', (128, 96, 3, 3)),
     ('inception_1/5x5_reduce', (16, 64, 1, 1)),
     ('inception_1/5x5', (32, 16, 5, 5)),
     ('inception_1/pool_proj', (32, 64, 1, 1)),
     ('conv2/3x3_s1', (64, 256, 3, 3)),
     ('ip1', (500, 1152)),
     ('ip2', (3, 503))]




```python
solver.net.forward()  # train net
solver.test_nets[0].forward()  # test net (there can be more than one)
```




    {'loss': array(0.6951103806495667, dtype=float32)}




```python
# we use a little trick to tile the first eight images
imshow(solver.test_nets[0].blobs['data'].data[:8, 0].transpose(1, 0, 2).reshape(36, 8*60), cmap='gray')
print solver.net.blobs['label'].data[:8]
```

    [[ -2.44513273e-01   5.20949736e-02  -9.68245506e-01  -5.07045567e-01
       -1.12138920e-01  -2.90884897e-02]
     [ -7.41908699e-02   2.27922529e-01  -9.70848620e-01  -1.28387764e-01
        1.65355857e-02   1.06296828e-03]
     [ -1.74087971e-01   3.04691344e-02  -9.84258592e-01  -9.52000245e-02
       -3.14195365e-01  -1.50917871e-02]
     [ -2.49744281e-02   1.77879885e-01  -9.83735263e-01  -7.38587156e-02
       -1.21144764e-02  -4.47588827e-04]
     [ -1.61419377e-01   5.79187945e-02  -9.85184848e-01  -1.06810793e-01
        1.42905980e-01   7.65229668e-03]
     [ -1.52415037e-01   2.09456533e-01  -9.65866268e-01  -5.29863574e-02
       -1.14266567e-01  -3.03129526e-03]
     [ -1.76816806e-02   6.62708879e-02  -9.97644961e-01  -6.35477304e-02
       -2.95568883e-01  -9.46362782e-03]
     [  1.79661021e-01   2.34958977e-01  -9.55257118e-01  -8.40480402e-02
        1.60711512e-01   6.77234307e-03]]



![png](output_4_1.png)



```python
solver.step(1)
```


```python
imshow(solver.net.params['conv1/5x5_s1'][0].diff[:, 0].reshape(8, 8, 5, 5)
       .transpose(0, 2, 1, 3).reshape(8*5, 8*5), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f3468038a90>




![png](output_6_1.png)


Show the conv1 weights pics.


Then, I will train the model, and log some information.


```python
%%time
niter = 2000
test_interval = 25
# losses will also be stored in the log
train_loss = zeros(niter)
mean_error= zeros(int(np.ceil(niter / test_interval)))
output = zeros((niter, 8, 3))

# the main solver loop
for it in range(niter):
    solver.step(1)  # SGD by Caffe
    
    # store the train loss
    train_loss[it] = solver.net.blobs['loss'].data
    
    # store the output on the first test batch
    # (start the forward pass at conv1 to avoid loading new data)
    solver.test_nets[0].forward(start='conv1/5x5_s1')
    output[it] = solver.test_nets[0].blobs['ip2'].data[:8]
    if it % test_interval == 0:
        # caculate the square error for each gaze vector
        solver.test_nets[0].forward()
        
        num_test = 100;
        sub_error = zeros((num_test, 3))
        square_error = zeros((num_test, 3))
        sum_Euclidean_error = zeros(num_test)
        for i in range(num_test):
            sub_error[i,:] = np.subtract(solver.test_nets[0].blobs['gaze'].data[i]
                                         , solver.test_nets[0].blobs['ip2'].data[i])
            square_error = np.square(sub_error)
            sum_Euclidean_error = np.sum(square_error,1)
            sum_Euclidean_error = np.sqrt(sum_Euclidean_error)/6
        mean_error[it // test_interval] = np.sum(sum_Euclidean_error,0)/num_test*180
        print 'Iteration', it, '. Mean error is', mean_error[it // test_interval]
```

    Iteration 0 . Mean error is 53.5124040901
    Iteration 25 . Mean error is 8.17681765177
    Iteration 50 . Mean error is 5.96818949135
    Iteration 75 . Mean error is 5.37435344871
    Iteration 100 . Mean error is 5.54494377309
    Iteration 125 . Mean error is 6.12722207435
    Iteration 150 . Mean error is 5.30460143611
    Iteration 175 . Mean error is 5.30809339867
    Iteration 200 . Mean error is 6.24933839396
    Iteration 225 . Mean error is 5.28854165419
    Iteration 250 . Mean error is 5.30996841323
    Iteration 275 . Mean error is 5.74247777189
    Iteration 300 . Mean error is 5.22978717104
    Iteration 325 . Mean error is 5.26579336018
    Iteration 350 . Mean error is 4.86929166538
    Iteration 375 . Mean error is 5.58589776709
    Iteration 400 . Mean error is 4.87053941996
    Iteration 425 . Mean error is 4.64282833892
    Iteration 450 . Mean error is 5.24174259354
    Iteration 475 . Mean error is 4.84135069423
    Iteration 500 . Mean error is 4.46896570303
    Iteration 525 . Mean error is 4.43558602302
    Iteration 550 . Mean error is 4.42417260497
    Iteration 575 . Mean error is 4.48373357198
    Iteration 600 . Mean error is 4.42573068921
    Iteration 625 . Mean error is 5.27933064495
    Iteration 650 . Mean error is 4.38539487665
    Iteration 675 . Mean error is 3.9056835432
    Iteration 700 . Mean error is 4.64556678697
    Iteration 725 . Mean error is 4.53095003429
    Iteration 750 . Mean error is 4.02797772677
    Iteration 775 . Mean error is 4.2120763807
    Iteration 800 . Mean error is 4.59344779598
    Iteration 825 . Mean error is 3.77383197045
    Iteration 850 . Mean error is 3.945765185
    Iteration 875 . Mean error is 5.35380930142
    Iteration 900 . Mean error is 3.60361049576
    Iteration 925 . Mean error is 3.84691073395
    Iteration 950 . Mean error is 4.09682885934
    Iteration 975 . Mean error is 3.74966860824
    Iteration 1000 . Mean error is 4.103446606
    Iteration 1025 . Mean error is 3.78797110087
    Iteration 1050 . Mean error is 4.66877497853
    Iteration 1075 . Mean error is 4.30850767393
    Iteration 1100 . Mean error is 3.64866203412
    Iteration 1125 . Mean error is 4.34143306004
    Iteration 1150 . Mean error is 3.64491894318
    Iteration 1175 . Mean error is 3.57050066456
    Iteration 1200 . Mean error is 3.7582975143
    Iteration 1225 . Mean error is 3.97715910987
    Iteration 1250 . Mean error is 3.71755715782
    Iteration 1275 . Mean error is 3.61746279516
    Iteration 1300 . Mean error is 5.10612917032
    Iteration 1325 . Mean error is 3.51412391392
    Iteration 1350 . Mean error is 3.67702530128
    Iteration 1375 . Mean error is 4.18548252453
    Iteration 1400 . Mean error is 3.38920224912
    Iteration 1425 . Mean error is 3.64569244807
    Iteration 1450 . Mean error is 3.88921140046
    Iteration 1475 . Mean error is 3.95165980725
    Iteration 1500 . Mean error is 4.01943333109
    Iteration 1525 . Mean error is 3.41001137265
    Iteration 1550 . Mean error is 4.84604259289
    Iteration 1575 . Mean error is 3.57620630818
    Iteration 1600 . Mean error is 3.46872266409
    Iteration 1625 . Mean error is 3.80821233802
    Iteration 1650 . Mean error is 3.76035067808
    Iteration 1675 . Mean error is 3.52214995829
    Iteration 1700 . Mean error is 3.48659397854
    Iteration 1725 . Mean error is 4.00186144299
    Iteration 1750 . Mean error is 3.79795145842
    Iteration 1775 . Mean error is 3.47560351532
    Iteration 1800 . Mean error is 5.42310993874
    Iteration 1825 . Mean error is 3.39347430352
    Iteration 1850 . Mean error is 3.62320107778
    Iteration 1875 . Mean error is 3.88562835755
    Iteration 1900 . Mean error is 3.63503086254
    Iteration 1925 . Mean error is 3.94163020659
    Iteration 1950 . Mean error is 3.4923568318
    Iteration 1975 . Mean error is 4.42540407163
    CPU times: user 6min 42s, sys: 1min 7s, total: 7min 49s
    Wall time: 7min 49s



```python
_, ax1 = subplots()
ax2 = ax1.twinx()
ax1.plot(arange(niter), train_loss)
ax2.plot(test_interval * arange(len(mean_error)), mean_error, 'r')
ax1.set_xlabel('iteration')
ax1.set_ylabel('train loss')
ax2.set_ylabel('mean error')
```




    <matplotlib.text.Text at 0x7f345f48c610>




![png](output_9_1.png)


**show you the train loss curve.


```python
num_test = 1000


# (start the forward pass at conv1 to avoid loading new data)
solver.test_nets[0].forward(start='conv1/5x5_s1')
solver.test_nets[0].forward()

#figure(figsize=(10, 5))
#imshow(solver.test_nets[0].blobs['data'].data[:num_test, 0].transpose(1, 0, 2).reshape(36, num_test*60), cmap='gray')
    
#Print the label and train result
#for i in range(num_test):
#    print solver.test_nets[0].blobs['label'].data[i,:3] ,'label<->ip2', solver.test_nets[0].blobs['ip2'].data[i]

print '--------------------------------------------------------------------------------------------------------------'
# caculate the square error for each gaze vector
sub_error = zeros((num_test, 3))
square_error = zeros((num_test, 3))
sum_square_error = zeros(num_test)
for i in range(num_test):
    sub_error[i,:] = np.subtract(solver.test_nets[0].blobs['label'].data[i,:3], solver.test_nets[0].blobs['ip2'].data[i])
    square_error = np.square(sub_error)
    sum_square_error = np.sum(square_error,1)
    sum_square_error = np.sqrt(sum_square_error)/6
    #print sub_error[i,:],square_error[i,:],sum_square_error[i]
    #print sum_square_error[i],

print num_test,'test pic, mean error is ',np.sum(sum_square_error,0)/num_test*180,'degree'
_, ax1 = subplots()
ax1.plot(arange(num_test), sum_square_error*180,'bo', label='sampled')
ax1.set_xlabel('num_test')
ax1.set_ylabel('sum_square_error')
    
```

    --------------------------------------------------------------------------------------------------------------
    1000 test pic, mean error is  3.78514890409 degree





    <matplotlib.text.Text at 0x7f345f361810>




![png](output_11_2.png)



```python
imshow(solver.net.params['conv1/5x5_s1'][0].diff[:, 0].reshape(8, 8, 5, 5)
       .transpose(0, 2, 1, 3).reshape(8*5, 8*5), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f345f2a7c90>




![png](output_12_1.png)



```python
figure(figsize=(10, 5))
imshow(solver.net.params['conv2/3x3_s1'][0].diff[:, 0].reshape(8, 8, 3, 3)
       .transpose(0, 2, 1, 3).reshape(8*3, 8*3), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f345f1e4850>




![png](output_13_1.png)



```python
figure(figsize=(20, 10))
imshow(solver.test_nets[0].blobs['conv1/5x5_s1'].data[:8, :].reshape(16,32,32,56)
           .transpose(0,2,1,3).reshape(16*32, 32*56), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f345f17ac90>




![png](output_14_1.png)



```python
figure(figsize=(20, 10))
imshow(solver.test_nets[0].blobs['conv2/3x3_s1'].data[:8, :].reshape(16, 32, 6, 12)
       .transpose(0,2,1,3).reshape(16*6,32*12), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f345e8526d0>




![png](output_15_1.png)



```python
figure(figsize=(50, 25))
imshow(solver.test_nets[0].blobs['pool2/3x3_s2'].data[:8, :].reshape(64, 32, 8, 14)
       .transpose(0,2,1,3).reshape(64*8,32*14), cmap='gray')

```




    <matplotlib.image.AxesImage at 0x7f345f114a90>




![png](output_16_1.png)



```python
#solver.net.save('my_model.caffemodel') I do not know how to use this.
solver.snapshot() #SAVE MY MODEL IN THE DIR YOU DEFINE IN SOLVER FILE.
```


```python

```
