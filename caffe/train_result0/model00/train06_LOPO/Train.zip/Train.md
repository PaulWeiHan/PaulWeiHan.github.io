

```python
import os
os.chdir('/home/renwh/gaze/renwh/caffe_with_cudnnv3/')

import sys
sys.path.insert(0,'./python')
import caffe

from pylab import *
%matplotlib inline


caffe.set_device(0)
caffe.set_mode_gpu()
solver = caffe.SGDSolver('examples/mymodel/00/lenet_solver.prototxt')

#You can choose to load your model status
#solver.restore('examples/mymodel/03/lenet_iter_1001.solverstate')
```


```python
# each output is (batch size, feature dim, spatial dim)
[(k, v.data.shape) for k, v in solver.net.blobs.items()]
```




    [('data', (1000, 1, 36, 60)),
     ('label', (1000, 6)),
     ('gaze', (1000, 3)),
     ('headpose', (1000, 3)),
     ('conv1', (1000, 20, 32, 56)),
     ('pool1', (1000, 20, 16, 28)),
     ('conv2', (1000, 50, 12, 24)),
     ('pool2', (1000, 50, 6, 12)),
     ('ip1', (1000, 500)),
     ('cat', (1000, 503)),
     ('ip2', (1000, 3)),
     ('loss', ())]




```python
# just print the weight sizes (not biases)
[(k, v[0].data.shape) for k, v in solver.net.params.items()]
```




    [('conv1', (20, 1, 5, 5)),
     ('conv2', (50, 20, 5, 5)),
     ('ip1', (500, 3600)),
     ('ip2', (3, 503))]




```python
solver.net.forward()  # train net
solver.test_nets[0].forward()  # test net (there can be more than one)
```




    {'loss': array(0.526023268699646, dtype=float32)}




```python
# we use a little trick to tile the first eight images
imshow(solver.test_nets[0].blobs['data'].data[:8, 0].transpose(1, 0, 2).reshape(36, 8*60), cmap='gray')
print solver.net.blobs['label'].data[:8]
```

    [[ -2.44513273e-01   5.20949736e-02  -9.68245506e-01  -5.07045567e-01
       -1.12138920e-01  -2.90884897e-02]
     [ -7.41908699e-02   2.27922529e-01  -9.70848620e-01  -1.28387764e-01
        1.65355857e-02   1.06296828e-03]
     [ -1.74087971e-01   3.04691344e-02  -9.84258592e-01  -9.52000245e-02
       -3.14195365e-01  -1.50917871e-02]
     [ -2.49744281e-02   1.77879885e-01  -9.83735263e-01  -7.38587156e-02
       -1.21144764e-02  -4.47588827e-04]
     [ -1.61419377e-01   5.79187945e-02  -9.85184848e-01  -1.06810793e-01
        1.42905980e-01   7.65229668e-03]
     [ -1.52415037e-01   2.09456533e-01  -9.65866268e-01  -5.29863574e-02
       -1.14266567e-01  -3.03129526e-03]
     [ -1.76816806e-02   6.62708879e-02  -9.97644961e-01  -6.35477304e-02
       -2.95568883e-01  -9.46362782e-03]
     [  1.79661021e-01   2.34958977e-01  -9.55257118e-01  -8.40480402e-02
        1.60711512e-01   6.77234307e-03]]



![png](output_4_1.png)



```python
solver.step(1)
```


```python
imshow(solver.net.params['conv1'][0].diff[:, 0].reshape(4, 5, 5, 5)
       .transpose(0, 2, 1, 3).reshape(4*5, 5*5), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f80269feb90>




![png](output_6_1.png)


Show the conv1 weights pics.


Then, I will train the model, and log some information.


```python
%%time
niter = 1000
test_interval = 25
# losses will also be stored in the log
train_loss = zeros(niter)
mean_error= zeros(int(np.ceil(niter / test_interval)))
output = zeros((niter, 8, 3))


# the main solver loop
for it in range(niter):
    solver.step(1)  # SGD by Caffe
    
    # store the train loss
    train_loss[it] = solver.net.blobs['loss'].data
    
    # store the output on the first test batch
    # (start the forward pass at conv1 to avoid loading new data)
    solver.test_nets[0].forward(start='conv1')
    output[it] = solver.test_nets[0].blobs['ip2'].data[:8]
    # run a full test every so often
    # (Caffe can also do this for us and write to a log, but we show here
    #  how to do it directly in Python, where more complicated things are easier.)
    if it % test_interval == 0:
        # caculate the square error for each gaze vector
        solver.test_nets[0].forward()
        
        num_test = 100;
        sub_error = zeros((num_test, 3))
        square_error = zeros((num_test, 3))
        sum_square_error = zeros(num_test)
        for i in range(num_test):
            sub_error[i,:] = np.subtract(solver.test_nets[0].blobs['label'].data[i,:3]
                                         , solver.test_nets[0].blobs['ip2'].data[i])
            square_error = np.square(sub_error)
            sum_square_error = np.sum(square_error,1)
        mean_error[it // test_interval] = np.sum(sum_square_error,0)/num_test*180
        print 'Iteration', it, '. Mean error is', mean_error[it // test_interval]
    
```

    Iteration 0 . Mean error is 65.9608403258
    Iteration 25 . Mean error is 9.45729590024
    Iteration 50 . Mean error is 4.5950719253
    Iteration 75 . Mean error is 4.15977474077
    Iteration 100 . Mean error is 5.85757056314
    Iteration 125 . Mean error is 3.33275092929
    Iteration 150 . Mean error is 4.71393372379
    Iteration 175 . Mean error is 2.65090532091
    Iteration 200 . Mean error is 2.92097415318
    Iteration 225 . Mean error is 3.13891075223
    Iteration 250 . Mean error is 2.60674436261
    Iteration 275 . Mean error is 5.42686761378
    Iteration 300 . Mean error is 2.26133539501
    Iteration 325 . Mean error is 2.6648637156
    Iteration 350 . Mean error is 3.49084893616
    Iteration 375 . Mean error is 2.19424956343
    Iteration 400 . Mean error is 5.23632787181
    Iteration 425 . Mean error is 2.38421196041
    Iteration 450 . Mean error is 2.2846063589
    Iteration 475 . Mean error is 2.80356628724
    Iteration 500 . Mean error is 2.00435280279
    Iteration 525 . Mean error is 5.09673921103
    Iteration 550 . Mean error is 2.28809341284
    Iteration 575 . Mean error is 2.31805235797
    Iteration 600 . Mean error is 2.51453277084
    Iteration 625 . Mean error is 2.53831868234
    Iteration 650 . Mean error is 3.46937736108
    Iteration 675 . Mean error is 1.99241043849
    Iteration 700 . Mean error is 3.49523087602
    Iteration 725 . Mean error is 1.81461353881
    Iteration 750 . Mean error is 2.28517776334
    Iteration 775 . Mean error is 4.74161303453
    Iteration 800 . Mean error is 1.93161310543
    Iteration 825 . Mean error is 3.68112345591
    Iteration 850 . Mean error is 2.4632606992
    Iteration 875 . Mean error is 1.73679236322
    Iteration 900 . Mean error is 4.19918287934
    Iteration 925 . Mean error is 2.19052613029
    Iteration 950 . Mean error is 2.88572552468
    Iteration 975 . Mean error is 2.1865343864
    CPU times: user 1min 5s, sys: 9.05 s, total: 1min 14s
    Wall time: 1min 14s



```python
_, ax1 = subplots()
ax2 = ax1.twinx()
ax1.plot(arange(niter), train_loss)
ax2.plot(test_interval * arange(len(mean_error)), mean_error, 'r')
ax1.set_xlabel('iteration')
ax1.set_ylabel('train loss')
ax2.set_ylabel('mean error')
```




    <matplotlib.text.Text at 0x7f8026885f90>




![png](output_9_1.png)


**show you the train loss curve.


```python
num_test = 1000
#figure(figsize=(10, 5))
#imshow(solver.test_nets[0].blobs['data'].data[:num_test, 0].transpose(1, 0, 2).reshape(36, num_test*60), cmap='gray')
    
# print the label and train result
#for i in range(num_test):
#    print solver.test_nets[0].blobs['label'].data[i,:3] ,'label<->ip2', solver.test_nets[0].blobs['ip2'].data[i]

# (start the forward pass at conv1 to avoid loading new data)
solver.test_nets[0].forward(start='conv1')
solver.test_nets[0].forward()

print '--------------------------------------------------------------------------------------------------------------'
# caculate the square error for each gaze vector
sub_error = zeros((num_test, 3))
square_error = zeros((num_test, 3))
sum_square_error = zeros(num_test)
for i in range(num_test):
    sub_error[i,:] = np.subtract(solver.test_nets[0].blobs['label'].data[i,:3], solver.test_nets[0].blobs['ip2'].data[i])
    square_error = np.square(sub_error)
    sum_square_error = np.sum(square_error,1)
    #print sub_error[i,:],square_error[i,:],sum_square_error[i]
    #print sum_square_error[i],
print num_test,'test pic, mean error is ',np.sum(sum_square_error,0)/num_test*180,'degree'
_, ax1 = subplots()
ax1.plot(arange(num_test), sum_square_error*180,'bo', label='sampled')
ax1.set_xlabel('num_test')
ax1.set_ylabel('sum_square_error')
```

    --------------------------------------------------------------------------------------------------------------
    1000 test pic, mean error is  2.32883394244 degree





    <matplotlib.text.Text at 0x7f802632e090>




![png](output_11_2.png)



```python
imshow(solver.net.params['conv1'][0].diff[:, 0].reshape(4, 5, 5, 5)
       .transpose(0, 2, 1, 3).reshape(4*5, 5*5), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f8026425cd0>




![png](output_12_1.png)



```python
figure(figsize=(10, 5))
imshow(solver.net.params['conv2'][0].diff[:, 0].reshape(5, 10, 5, 5)
       .transpose(0, 2, 1, 3).reshape(5*5, 10*5), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f8026310850>




![png](output_13_1.png)



```python
figure(figsize=(20, 10))
imshow(solver.test_nets[0].blobs['conv1'].data[:8, :].reshape(8,20,32,56)
           .transpose(0,2,1,3).reshape(8*32, 20*56), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f8024316810>




![png](output_14_1.png)



```python
figure(figsize=(50, 25))
imshow(solver.test_nets[0].blobs['conv2'].data[:8, :].reshape(16, 25, 12, 24)
       .transpose(0,2,1,3).reshape(16*12, 25*24), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f802428c290>




![png](output_15_1.png)



```python
#solver.net.save('my_model.caffemodel') I do not know how to use this.
solver.snapshot() #SAVE MY MODEL IN THE DIR YOU DEFINE IN SOLVER FILE.
```


```python

```
